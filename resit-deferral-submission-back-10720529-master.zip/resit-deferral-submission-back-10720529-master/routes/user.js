const Router = require('koa-router');
const bodyParser = require('koa-bodyparser');
const bcrypt = require('bcrypt');

const users = require('../models/user');
const authenticate = require('../controllers/auth');
const can = require('../permissions/users');
const {validateUser} = require('../controllers/validation');

const prefix = '/api/v1/users';
const router = Router({prefix: prefix});



router.get('/', authenticate, getAll);
router.post('/', bodyParser(),validateUser, createUser);
router.get('/:id([0-9]{1,})', authenticate, getById);
router.put('/:id([0-9]{1,})', authenticate, bodyParser(),validateUser, updateUser);
router.del('/:id([0-9]{1,})', authenticate, deleteUser);
router.post('/login', authenticate, login);

async function createUser(ctx){
  const body = ctx.request.body;
  const hash = bcrypt.hashSync(body.password, 10);
  body.saltedPassword = body.password;
  body.password = hash;
  const result = await users.add(body);
  if (result.affectedRows){
    const id = result.insertId;
    ctx.status = 201;
    ctx.body = {userID: result.insertId, created: true, link: `${ctx.request.path}/${result.insertId}`};
  }
}

async function getAll(ctx){
  const permission = can.readAll(ctx.state.user);
  if (!permission.granted) {
    ctx.status = 403;// 403 forbidden status code
    console.log(`The user is basic user and it is forbidden!`);
  } else {
    const result = await users.getAll();
    if(result.length){
      ctx.body = result;
      console.log(`The user is the admin`);
    }
  }
}


async function getById(ctx){
  
  const id = ctx.params.id;
  let result = await users.getById(id);
  if(result.length){
    const user = result[0];
    console.log("Get A user", user);
    const permission = can.readUser(ctx.state.user, user);
    
    if(!permission.granted){
      ctx.status = 403;// 403 forbbiden statuse code
      ctx.body = {message: `This user is not able to view this data`};
      console.log(`The data is un viewable for this user`);
    }else{
      ctx.body = user;
      console.log(`this user able to see its own data`);
    }
  }
}


async function updateUser(ctx){
  const id = ctx.params.id;
  let result = await users.getById(id);// check it exists
  if (result.length){
    const user = result[0];
    console.log("Update a user", user);
    const permission = can.updateUser(ctx.state.user, user);
    
    if(!permission.granted){
      ctx.status = 403;// 403 forbbiden statuse code
      ctx.body = {message: `This user is not able to update this data`};
      console.log(`The data is un viewable for this user`);
    }else{
          // exclude fields that should not be updated
    const {userID, role, ...body} = ctx.request.body;
    
    // overwrite updatable fields with remaining body data
    Object.assign(user, body);
    
    // edit for hashing
    const hash = bcrypt.hashSync(user.password, 10);
    user.saltedPassword = user.password;
    user.password = hash;
    //end edit
    
    result = await users.update(user);
    if(result.affectedRows){
      ctx.status =201;
      ctx.body = {userID: id, updated: true, link: ctx.request.path};
      }
    }
  }
}

async function deleteUser(ctx) {
  
  const id = ctx.params.id;
  let result = await users.getById(id);
  if(result.length){
    
    const user = result[0];
    console.log("Deleting user", user);
    const permission = can.deleteUser(ctx.state.user, user);
    
    if(!permission.granted){
      ctx.status = 403;
    }else{
      
      result = await users.delById(id);
      
      if(result.affectedRows){
        ctx.body = {ID: id, deleted: true};
      }
    }
  }
}

// Login using HATEOS
async function login(ctx){
  //return any details needed by the client
  const{userID, userName, email , role} = ctx.state.user
  const links = {
    self: `${ctx.protocol}s://${ctx.host}${prefix}/${userID}`
  }
  ctx.body = {userID,userName,email, role, links};
}

module.exports = router;