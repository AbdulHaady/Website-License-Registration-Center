const Router = require('koa-router');
const bodyParser = require('koa-bodyparser');

const licenses = require('../models/licenses');
const {validateLicense} = require('../controllers/validation');
const authenticate = require('../controllers/auth');
const can = require('../permissions/users');


const prefix = '/api/v1/licenses';
const router = Router({prefix: prefix});


router.get('/',  getAll);
router.post('/', bodyParser(), validateLicense,createLicense);
router.put('/:id([0-9]{1,})', bodyParser(), validateLicense,  updateLicense);
router.get('/:id([0-9]{1,})', getById);
router.del('/:id([0-9]{1,})', deleteLicense);

// router for request license for spesific user
router.get('/:id([0-9]{1,})/licenses', getLicense);


async function getAll(ctx){
  const {page=1, limit=100, order="dateCreated", direction='ASC'}=ctx.request.query;
  const result = await licenses.getAll(page, limit, order,direction);
  if(result.length){
    const body = result.map(post=>{
      //extract the post fields we want to send back (summary details)
      const{licenseID, licenseName, dateRequest, status, requester, description, companyName, companyAdress}= post;
      //add links to the post summaries for HATEOAS compilance
      //cients can follow these to find related resources
      const links ={
        self: `${ctx.protocol}://${ctx.host}${prefix}/${post.licenseID}`
      }
      return{licenseID, licenseName, dateRequest, status, requester, description, companyName, companyAdress};
    });
    ctx.body = body;
  }
}

async function getById(ctx){
  let id = ctx.params.id;
  let result = await licenses.getById(id);
  if (result.length){
    const license = result[0];

      ctx.body = license;
      console.log(`this user able to see its own license`);


  }
}






async function createLicense(ctx){
  const body = ctx.request.body;
  const result = await licenses.add(body);
  if (result.affectedRows){
    const id = result.insertId;
    ctx.status = 201;
    ctx.body = {licenseID: id, created: true, link: `${ctx.request.path}/${id}`};
  }
}


async function updateLicense(ctx){
  const id = ctx.params.id;
  let result = await licenses.getById(id);// check it exists
  if (result.length){
    let license = result[0];
    // exclude fields that should not be updated
    const {licenseID, dateRequest, ...body} = ctx.request.body;
    // overwrite updatable fields with remaining body data
    Object.assign(license, body);
    result = await licenses.update(license);
    if(result.affectedRows){
      ctx.status =201;
      ctx.body = {licenseID: id, updated: true, link: ctx.request.path};
    }
  }
}

async function deleteLicense (ctx){
  const id = ctx.params.id;
  const result = await licenses.delById(id);
  if (result.affectedRows){
    ctx.status = 201;
    ctx.body = {licenceID: id, deleted: true}
  }
  
}


//Get all license for spesific user <== a bit complicated
async function getLicense(ctx){
  const id = ctx.params.id;
  const result = await licenses.getLicense(id);
  if (result.length){
    ctx.body = result;
  }
}

module.exports = router;