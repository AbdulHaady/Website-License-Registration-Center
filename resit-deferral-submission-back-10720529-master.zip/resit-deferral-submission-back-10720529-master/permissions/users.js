const AccessControl = require('role-acl');
const ac = new AccessControl();


// user///
ac.grant('user').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('read').on('user',['*','!password','!saltedPassword']);
ac.grant('user').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('read').on('license');
ac.grant('user').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('update').on('user',['firstName','lastName','password','email']);
ac.grant('user').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('delete').on('user');
// admin//
ac.grant('admin').execute('read').on('user');
ac.grant('admin').execute('read').on('users');
ac.grant('admin').execute('update').on('user');
ac.grant('admin').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('delete').on('user');
ac.grant('admin').execute('read').on('licenses');
ac.grant('admin').execute('read').on('license');
// staff//
ac.grant('staff').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('read').on('user',['*','!password','!saltedPassword']);
ac.grant('staff').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('update').on('user',['firstName','lastName','password','email']);
ac.grant('staff').condition({Fn:'EQUALS', args:{'requester':'$.owner'}}).execute('delete').on('user');




// function //
exports.readAll = (requester) => ac.can(requester.role).execute('read').sync().on('users');
exports.read = (requester) => ac.can(requester.role).execute('read').sync().on('user');
//exports.readLicense = (requester) => ac.can(requester.role).execute('read').sync().on('license');//<test
exports.readUser = (requester, data) => ac.can(requester.role).context({requester:requester.ID, owner:data.ID}).execute('read').sync().on('user');
//exports.readlicense = (requester, data) => ac.can(requester.role).context({requester:requester.ID, owner:data.ID}).execute('read').sync().on('license');
exports.deleteUser = (requester, data) => ac.can(requester.role).context({requester:requester.ID, owner:data.ID}).execute('delete').sync().on('user');
exports.updateUser = (requester, data) => ac.can(requester.role).context({requester:requester.ID, owner:data.ID}).execute('update').sync().on('user');
