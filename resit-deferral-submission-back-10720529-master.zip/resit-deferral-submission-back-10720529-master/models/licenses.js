const db = require('../helpers/database');

//get a single license by its id
exports.getById = async function getById (id) {
  let query = "SELECT * FROM license WHERE licenseID = ?";
  let values = [id];
  let data = await db.run_query(query, values);
  return data;
}

//list all the license in the database
exports.getAll = async function getAll (page, limit, order) {
  // TODO: use page, limit, order to give pagination
  let query = "SELECT * FROM license";
  let data = await db.run_query(query);
  return data;
}

//create a new license in the database
exports.add = async function add(license) {
  let query = "INSERT INTO license SET ?";
  let data = await db.run_query(query, license);
  return data;
}

//delete licence in the database
exports.delById = async function delById (id){
  const query = "DELETE FROM license WHERE licenseID = ?;";
  const values = [id];
  const data = await db.run_query(query, values);
  return data;
}

// update existing license
exports.update = async function update (license){
  const query = "UPDATE license SET ? WHERE licenseID = ?;";
  const values = [license, license.licenseID];
  const data = await db.run_query(query, values);
  return data;
}

// get the license for spesific user
exports.getLicense = async function getLicense (id){
  
  const query = "SELECT * FROM license WHERE requesterID = ?;";
  const data = await db.run_query(query, [id]);
  return data;
  
}