const db = require('../helpers/database');

//get a single user by its id
exports.getById = async function getById (id) {
  let query = "SELECT * FROM user WHERE userID = ?";
  let values = [id];
  let data = await db.run_query(query, values);
  return data;
}

//list all the user in the database
exports.getAll = async function getAll (page, limit, order) {
  // TODO: use page, limit, order to give pagination
  let query = "SELECT * FROM user";
  let data = await db.run_query(query);
  return data;
}

//create a new user in the database
exports.add = async function add(user) {
  let query = "INSERT INTO user SET ?";
  let data = await db.run_query(query, user);
  return data;
}

//delete user in the database
exports.delById = async function delById (id){
  const query = "DELETE FROM user WHERE userID = ?;";
  const values = [id];
  const data = await db.run_query(query, values);
  return data;
}

// update existing user
exports.update = async function update (user){
  const query = "UPDATE user SET ? WHERE userID = ?;";
  const values = [user, user.userID];
  const data = await db.run_query(query, values);
  return data;
}

//get a single user by the (unique) username
exports.findByUsername = async function getByUsername(username){
  const query = "SELECT * FROM user WHERE userName= ?;";
  const user = await db.run_query(query,username);
  return user;
}