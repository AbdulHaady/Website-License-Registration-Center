const Koa = require('koa');
const cors= require('@koa/cors');

const app = new Koa();

const special = require('./routes/special.js');
const licenses = require('./routes/licenses.js');
const users = require('./routes/user.js');

app.use(cors());
app.use(special.routes());
app.use(licenses.routes());
app.use(users.routes());


let port = process.env.PORT || 3000;

app.listen(port);
