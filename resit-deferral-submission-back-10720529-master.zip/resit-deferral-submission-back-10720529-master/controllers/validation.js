const {Validator, ValidationError} = require('jsonschema');

const licenseSchema = require('../schemas/license.json').definitions.license;
const userSchema = require('../schemas/user.json').definitions.user;
const userUpdateSchema = require('../schemas/user.json').definitions.updateUser;



const makeKoaValidator = (schema, resource) => {
  
  const v = new Validator();
  const validationOptions = {
    throwError: true,
    propertyName: resource
  };
  
  const handler = async (ctx, next)=>{
    
    const body = ctx.request.body;
  
    try {
      v.validate(body, schema, validationOptions);
      await next();
    } catch (error){
      if(error instanceof ValidationError){
        console.error(error);
        ctx.status = 400
        ctx.body = error;
      } else {
        throw error;
      }
    }
  }
  return handler;
}

exports.validateLicense = makeKoaValidator(licenseSchema, 'license');
exports.validateUser = makeKoaValidator(userSchema, 'user');
exports.validateUpdateUser = makeKoaValidator(userUpdateSchema, 'updateUser');