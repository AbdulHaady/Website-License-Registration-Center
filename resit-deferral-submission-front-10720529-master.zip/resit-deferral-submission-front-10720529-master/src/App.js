import React from 'react';
import './App.css';
import { Layout} from 'antd';

import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

//The function and page for the website
import Nav from './components/nav';
import Home from './components/home';
import Login from './components/login';
import Post from './components/post';
import PostStaff from './components/postStaff';
import Register from './components/register';

import BlogGrid from './components/blogGridT';

import AdminDisplayUser from './components/adminDisplayUser';
import AdminDeleteUser from './components/adminDeleteUser';
import AdminUpdateUser from './components/adminUpdateUser';
import PostUser from './components/postUser';

import LicenseDisplayList from './components/licenseDisplayList';
import LicenseCreate from './components/licenseCreate';
import LicenseList from './components/licenseList';
import LicenseTab from './components/licenseTab';
import LicenseUpdate from './components/licenseUpdate';
import LicenseDelete from './components/licenseDelete';
import StaffLicenseSearchPage from './components/staffLicenseSearchPage';
import LicenseUpdateStaff from './components/licenseUpdateStaff';

import SearchLicense from './components/searchLicense';

import UserDelete from './components/userDelete';
import UserUpdate from './components/userUpdate';
import UserSearchLicense from './components/userSearchLicense';
import UserSearchLicenseBar from './components/userSearchLicenseBar';
import UserSearchLicenseList from './components/userSearchLicenseList';
import UserLicense from './components/userLicense';
import UserLicensePostCard from './components/userLicensePostCard';

//Context user validation
import UserContext from './contexts/user';


const { Header, Content, Footer } = Layout;

class App extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            user: {loggedIn: false}
        }
        
        this.login = this.login.bind(this);
        this.logout = this.logout.bind(this);
    }
    
    login(user) {
        console.log("User is now being set on the context");
        user.loggedIn = true;
        this.setState({user:user});
    }
    
    logout() {
        console.log("Removing user from the app context");
        this.setState({user: {loggedIn:false}});
    }
    
    render () {
        const context = {
            user: this.state.user,
            login: this.login,
            logout: this.logout
        };


  return (
    <UserContext.Provider value={context}>
      <Router>
    
          <Header>
            <Nav />
          </Header>
    
            <Content>
              <Switch>

                <Route path="/adminDisplayUser" children={<AdminDisplayUser />} />
                <Route path="/adminDeleteUser" children={<AdminDeleteUser />} />
                <Route path="/adminUpdateUser" children={<AdminUpdateUser />} />
                  
                <Route path="/userDelete" children={<UserDelete />} />
                <Route path="/userUpdate" children={<UserUpdate />} />
                <Route path="/userSearchLicense" children={<UserSearchLicense />} />
                <Route path="/userSearchLicenseBar" children={<UserSearchLicenseBar />} />
                <Route path="/userSearchLicenseList" children={<UserSearchLicenseList />} />
                <Route path="/userLicense" children={<UserLicense />} />
                <Route path="/userLicensePostCard" children={<UserLicensePostCard />} />
                  
                <Route path="/register" children={<Register />} />
                <Route path="/postUser/:id" children={<PostUser />} />
                <Route path="/postStaff/:id" children={<PostStaff />} />
                     
                <Route path="/licenseTab" children={<LicenseTab />} />
                <Route path="/licenseList" children={<LicenseList />} />
                <Route path="/licenseDisplayList" children={<LicenseDisplayList />} />
                <Route path="/licenseCreate" children={<LicenseCreate />} />
                <Route path="/licenseUpdate/:id" children={<LicenseUpdate />} />
                <Route path="/licenseDelete/:id" children={<LicenseDelete />} />
                <Route path="/staffLicenseSearchPage" children={<StaffLicenseSearchPage />} />
                <Route path="/licenseUpdateStaff" children={<LicenseUpdateStaff />} />
                  
                <Route path="/searchLicense" children={<SearchLicense />} />
                  
                <Route path="/blogGridT" children={<BlogGrid />} />

                <Route path="/login" children={<Login />} />                 
                <Route path="/post/:id" children={<Post />} />  

              
                <Route path="/" children={<Home />} exact/>

            
            </Switch>
          </Content>
        <Footer style={{ textAlign: 'center'}}>Created for the License Registration Center</Footer>
      </Router>
    </UserContext.Provider>
    );
  }
}

export default App;
