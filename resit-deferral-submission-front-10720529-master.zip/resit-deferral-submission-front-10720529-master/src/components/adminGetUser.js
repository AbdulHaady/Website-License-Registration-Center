//Same as blog grid
import React from 'react';
import { Col, Row } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import AdminUserList from './adminUserList';


import UserContext from '../contexts/user';



class GetAllUser extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            posts:[]
        }
    }
    
    static contextType = UserContext;//test
    
  componentDidMount() {
      
      const user = this.context.user;//test
      
      let headers = new Headers();
      headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));
      
      fetch('https://riviera-digital-3000.codio-box.uk/api/v1/users', {
          headers: headers
      })
      .then(status)
      .then(json)
      .then(data => {
          this.setState({posts: data})
      })
      .catch(err => console.log("Error fetching users", err));
  }
    
  render() {
    if (!this.state.posts.length) {
      return <h3>Loading user informations...</h3>
    }
      
    const cardList = this.state.posts.map(post => {
      return (
        <div style={{padding:"10px"}} key={post.id}>
          <Col span={6}>
            <AdminUserList{...post}/>
          </Col>
        </div>
      )
    });

    return (
      <Row type="flex" justify="space-around">
        {cardList}
      </Row>
    );
  }
};

export default GetAllUser;