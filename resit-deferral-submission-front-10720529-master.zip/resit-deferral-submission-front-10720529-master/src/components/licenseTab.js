//This is same as BlogGrid
import React from 'react';
import {Col, Row} from 'antd';
import LicenseList from './licenseList';
import { status, json } from '../utilities/requestHandlers';


class licenseTab extends React.Component {
    
  constructor(props){
    super(props);
    this.state = {
      posts:[]
    }
  }


  componentDidMount() {
    

    
    fetch('https://riviera-digital-3000.codio-box.uk/api/v1/licenses')
    .then(status)
    .then(json)
    .then(data => {
      this.setState({ posts: data })
    })
    .catch(err => console.log("Error fetching license", err));
  }
  

  
  render(){
    if(!this.state.posts.length){
      return<h3>Loading license...</h3>
    }
    
    //the next line does the Array.map() operation on the posts
    //to create an array of React elaments to be rendered
    const cardList = this.state.posts.map(post =>{
      return(
        <div style={{padding:"10px"}} key={post.id}>
          <Col span={6}> 
            <LicenseList{...post}/> 

          </Col>
        </div>
      )
    });
    return(
      <Row  type= "flex" justify = "space-around">
      <Col span ={12}>{cardList}</Col>
      </Row>
    );
  }
}

export default licenseTab;