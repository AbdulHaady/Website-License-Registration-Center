//this is used for the license
import React from 'react';
import { withRouter } from 'react-router';
import { Row, Col, Typography, Button } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import UserContext from '../contexts/user';//test
import { Link } from "react-router-dom";

const { Title, Paragraph } = Typography;



class PostUser extends React.Component {
  

  constructor(props){
    super(props);
    this.state = {
      post: undefined
    }
  }

   static contextType = UserContext;//test

  componentDidMount() {
    
    
     const user = this.context.user;//test
    
      let headers = new Headers();//test
      headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));//test
    
    const id = this.props.match.params.id; // available using withRouter()    
    fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/users/${id}`, {
          headers: headers
      })
    .then(status)
    .then(json)
    .then(post => {
      this.setState({ post: post })
    })
    .catch(err => console.log("Error fetching users", err));
  }
  

  
  render(){
    if(!this.state.post){
      return<h3>Loading license...</h3>
    }
    const post = this.state.post;


    return (
      <div>
         <Row type="flex" justify="space-around" align="middle">
          <Col span={6} align="center">
          <Title>{"   "}</Title>
          </Col>
         </Row>
        <Row type="flex" justify="space-around" align="middle">
          <Col span={6} align="center">
          </Col>
          <Col span={20}>
            <Title>{post.licenseName}</Title>
            <Paragraph>User ID : {post.userID}</Paragraph>
            <Paragraph>User Name : {post.userName}</Paragraph>
            <Paragraph>First Name : {post.firstName}</Paragraph>
            <Paragraph>Last Name : {post.lastName}</Paragraph>
            <Paragraph>Email : {post.email}</Paragraph>  
          </Col>
          <Col span={6} align="center">
          </Col>
        </Row>

         <Row type="flex" justify="space-around" align="middle">
          <Col span= {6} >
          <Button type="primary"><Link to ={`/adminDeleteUser/${post.licenseID}`}>Delete</Link></Button>
          </Col>
          <Col span={6} >
          <Button type="primary"><Link to ={`/adminUpdateUser`}>Update</Link></Button>
          </Col>
         </Row>



      </div>
    );
  }

}

export default withRouter(PostUser);