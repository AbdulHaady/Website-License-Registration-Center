import React, { useState, useEffect } from 'react';
import SearchLicenseBar from './userSearchLicenseBar';
import BlogGrid from './blogGridT';

import UserContext from '../contexts/user';
import {useContext} from 'react';//<


import { PageHeader } from 'antd';

const SearchLicense = (props) => {
  
  const context = useContext(UserContext);
  const user = context.user;
  console.log("current user in UserContext is", user.userName);
  
  
  const [input,setInput] = useState('');
  const [searchLicenseListDefault, setSearchLicenseListDefault] = useState();
  const [searchLicenseList, setSearchLicenseList] = useState();
  
  const fetchData = async () => {
    return await fetch('https://riviera-digital-3000.codio-box.uk/api/v1/licenses')
    .then(response => response.json())
    .then(data =>{setSearchLicenseList(data)
                 setSearchLicenseListDefault(data)});
  }
  
  const updateInput = async (input) =>{
      console.log("here 1",input);
      console.log("here 1", user.userName);
      const filtered = searchLicenseListDefault.filter (license =>{
                                                 
       return license.requester.toLowerCase().includes(input.toLowerCase())})
      console.log("here 2", filtered);
      setInput(input);
      setSearchLicenseList(filtered);
}
  
  useEffect( ()=> {fetchData()}, []);
  
  return (
    
    
    
  <>

          <PageHeader className="site-page-header"
           title="License Registeration Center"
           subTitle ="Lets Get A license"/>
        
        <SearchLicenseBar
        input = {input}
        setKeyword = {updateInput}
    />
          
     <BlogGrid searchLicenseList = {searchLicenseList?searchLicenseList:[]} />
  </>
  );
}

export default SearchLicense;