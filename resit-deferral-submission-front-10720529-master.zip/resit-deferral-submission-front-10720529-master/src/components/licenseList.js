//same as postcard
import React from 'react';
import { Card , Button} from 'antd';
import { Link } from "react-router-dom";


import UserContext from '../contexts/user';//test user context item 1


class LicenseList extends React.Component {
  
  
  static contextType = UserContext;//test user context item 2



  render() {
    
    const user = this.context.user;
    console.log("current user in UserContext is", user);
    
    const postID = this.props.licenseID;
    return (
      <Card
        style={{ width: 600 }}
        enterButton = "Open"
        size = "large"
        onClick = {null}
        title={this.props.licenseName} 
         extra={<Button type="primary"><Link to ={`/post/${postID}`}>Open</Link></Button>}


         hoverable={true}>
        <p>License ID : {this.props.licenseID}</p>
        <p>Status : {this.props.status}</p>
        
      </Card>
    );
  }
}

export default LicenseList; 