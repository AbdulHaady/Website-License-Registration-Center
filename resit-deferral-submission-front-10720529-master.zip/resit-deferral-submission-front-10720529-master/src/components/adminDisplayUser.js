// this same as home, and also amse as licenseDisplay

import React from 'react';
import { PageHeader } from 'antd';
import AdminGetUser from './adminGetUser';


function AdminHome (props){
  

    return(
          <div className= "site-layout-content">
      <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="The User List"
          subTitle= "This is where all the user at!"/>
       </div>
       <AdminGetUser />
      </div>
      
    );

};

export default AdminHome;