//In progress
import React from 'react';
import { Card } from 'antd';
import NavImage from './navImageT';

//const { Meta } = Card;

class PostCard extends React.Component {

//https://picsum.photos/id/1024/400

  render() {
    const postID = this.props.licenseID;
    return (
      <Card
        style={{ width: 320 }}
        cover={<NavImage alt={`Post ${postID}`} src="http://www.differencebetween.info/sites/default/files/images_articles_d7_1/commercial-license.jpg" to={`/postStaff/${postID}`} />}
        hoverable={true}>
        <p>License Name : {this.props.licenseName}</p>
        <p>License ID : {this.props.licenseID}</p>
        <p>Status : {this.props.status}</p>
        
      </Card>
    );
  }
}

export default PostCard; 