import React from 'react';
import { Form,Input,Button,PageHeader } from 'antd';
import { status, json } from '../utilities/requestHandlers';

/**
 * license form component for user request license.
 */

const formItemLayout ={
  labelCol: {xs: {span:24}, sm:{span:6}},
  wrapperCol: {xs:{span:24}, sm:{span:12}}
};


const btnFormItemLayout ={
    wrapperCol: { xs: {span:24, offset:6}, sm:{ span:16,offest:16}}
};

// Rules=======================

const requesterNameRules =[
  {required:true, message:'Please enter the requester name!'}
];

const requesterIDRules =[
  {required:true, message:'Please enter the ID!'}
];


const licenseNameRules =[
  {required:true, message:'Please enter the license name!'}
];

const descriptionRules = [
  {required: true, message: 'Please enter the description for the license!', whitespace:true}
];

const companyNameRules = [
  {required: true, message: 'Please enter the company name!', whitespace:true}
];

const companyAdressRules = [
  {required: true, message: 'Please enter the company adress!', whitespace:true}
];

// ============================

class RegistrationLicense extends React.Component{
  
  constructor(props){
    super(props);
    this.onFinish = this.onFinish.bind(this);
  }
  
  onFinish = (values) => {
    console.log('Recieved values of form: ', values);
    const {confirm, ...data}= values; //ignore the 'confirm' value
    
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
        
    console.log("Create Test", headers); //checking error
    
    fetch('https://riviera-digital-3000.codio-box.uk/api/v1/licenses',{
      method:"POST",
      body:JSON.stringify(data),
      headers:headers
    })
    .then(status)
    .then(json)
    .then(data=>{
         //For you TODO: display success message and/or redirect
         console.log(data);
         alert("license added")
    })
    .catch(error =>{
      //For you TODO: show nicely formatted error message and clear form
        console.error(error);
      alert(`Error:${error}`);
    });
  };
  
  
  render(){
    return(
          <div className= "site-layout-content">
      <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="Register License Here"
          subTitle= "Enter your license infromation"/>
       </div>

    <Form {...formItemLayout} name="register" onFinish={this.onFinish} scrollToFirstError>
      
      <Form.Item  name="requester" label="Requester Name" rules={requesterNameRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="requesterID" label="Requester ID" rules={requesterIDRules}>
        <Input />
      </Form.Item >
      
      <Form.Item  name="licenseName" label="License Name" rules={licenseNameRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="description" label="Description" rules={descriptionRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="companyName" label="Company Name" rules={companyNameRules}>
        <Input />
      </Form.Item >
      
      
      <Form.Item  name="companyAdress" label="Company Adress" rules={companyAdressRules}>
        <Input />
      </Form.Item>

      
      
      
      <Form.Item {...btnFormItemLayout} >
        <Button  type="primary" htmlType="submit">
          Register
        </Button>
      </Form.Item>
     </Form>

      </div>
      
    );
  };
};

export default RegistrationLicense;