//same as favourite Dog
import React from 'react';
import { Col, Row } from 'antd';
import UserLicensePostCard from './userLicensePostCard';
import { status, json } from '../utilities/requestHandlers';
import UserContext from '../contexts/user';





class UserLicense extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      posts: []
    }
  }
    
    static contextType = UserContext;

  componentDidMount() {
      
      const id = this.context.user.userID;
      const user = this.context.user;
      
      console.log(user);
      
      fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/licenses/${id}/licenses`)
      .then(status)
      .then(json)
      .then(data => {
          this.setState({posts: data})
      })
      .catch(err => console.log("Error fetching license ", err));
  }

  render() {
    if (!this.state.posts.length) {
      return <h3>Loading posts...</h3>
    }
      
    const cardList = this.state.posts.map(post => {
      return (
        <div style={{padding:"10px"}} key={post.ID}>
          <Col span={6}>
            <UserLicensePostCard {...post} />
          </Col>
        </div>
      )
    });

    return (
      <Row type="flex" justify="space-around">
        {cardList}
      </Row>
    );
  }
}

export default UserLicense;