import React from 'react';
import { Form, Input, Button, PageHeader, Row, Col } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';//test for the user context item 1


// layout =========================================================================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

// Rules ============================================================================================
const licenseIDRules =[
  {required:true, message:'Please enter the license ID!'}
];

const requesterNameRules =[
  {required:true, message:'Please enter the requester name!'}
];

const licenseNameRules =[
  {required:true, message:'Please enter the license name!'}
];

const descriptionRules = [
  {required: true, message: 'Please enter the description for the license!', whitespace:true}
];

const companyNameRules = [
  {required: true, message: 'Please enter the company name!', whitespace:true}
];

const companyAdressRules = [
  {required: true, message: 'Please enter the company adress!', whitespace:true}
];


// ==================================================================================================

class LicenseUpdate extends React.Component {
  

    
    constructor(props) {
        super(props);
        this.licenseUpdate = this.licenseUpdate.bind(this);
    }
    
    static contextType = UserContext;//test for the user Context item 2
    
    licenseUpdate = (values) => {
        console.log('Received values of form: ', values);
        const {licenseID, ...data} = values;  // ignore the 'confirm' value in data sent

        const user = this.context.user;
        console.log("current user in UserContext is", user);
       
        let headers = new Headers();
        headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));      
        headers.append('Content-Type', 'application/json');
        
        console.log(values.licenseID);
        
        fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/licenses/${values.licenseID}`, {
            method: "PUT",
            body: JSON.stringify(data),
            headers:headers
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("license updated")

            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
    
    render() {
        
        return (
          
           <div className= "site-layout-content">
          <div style={{ padding: '2% 20%'}}>
          <PageHeader className= "site-page-header"
          title="Update Your License"
          subTitle= "Enter your new license infromation"/>
       </div>

            <Form {...formItemLayout} name="licenseUpdate" onFinish={this.licenseUpdate} scrollToFirstError >
              
                      <Form.Item  name="licenseID" label="License ID" rules={licenseIDRules}>
                        <Input />
                      </Form.Item >
              
            
                      <Form.Item  name="requester" label="Requester Name" rules={requesterNameRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="licenseName" label="License Name" rules={licenseNameRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="description" label="Description" rules={descriptionRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="companyName" label="Company Name" rules={companyNameRules}>
                        <Input />
                      </Form.Item >


                      <Form.Item  name="companyAdress" label="Company Adress" rules={companyAdressRules}>
                        <Input />
                      </Form.Item>

                <Form.Item {...tailFormItemLayout}>
                  <Row>
                  <Col span={8}>
                    <Button type="primary" htmlType="submit">Update License</Button>
                  </Col>
                  <Col span={8}>
                    <Button type = "primary"><Link to = "/">Back</Link></Button>
                   </Col>
                   </Row>
                </Form.Item>
            </Form>

      </div>
        );
    };
};

export default LicenseUpdate;