//same as post card Dog
import React from 'react';
import { Card } from 'antd';
import NavImage from './navImageT';

const { Meta } = Card;

class PostCardLicense extends React.Component {
    
  render() {
    const postID = this.props.requesterID;
    const post = this.props.licenseID;
      

      
    return (
        
      <Card
        
        style = {{ width: 320 }}
        cover = {
            <NavImage alt = {`Post ${postID}`}
                      src = {"http://www.differencebetween.info/sites/default/files/images_articles_d7_1/commercial-license.jpg"}
                      to = {`/post/${post}`} />
        }

        hoverable = {true} >
        
        <Meta title ={"Requester Name : " +this.props.requester} description = {"Status : " +this.props.status} />
      </Card>
    );
  }
}

export default PostCardLicense; 