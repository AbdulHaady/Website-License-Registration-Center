import React from 'react';
import SearchLicense from './searchLicense';

function StaffLicenseSearchPage(props) {
    
  return (
      <div className="site-layout-content">
      
        <div style={{ padding: '2% 20%' }}>
      
          <SearchLicense />
                
        </div>  
        
      </div>
  );
}

export default StaffLicenseSearchPage;
