import React from 'react';

const SearchLicenseList = ({searchLicenseList=[]}) => {
  return (
    <>
    { searchLicenseList.map((data,index) => {
        if (data) {
          return (
            <div key={data.requester}>
              <h1>{data.requester}</h1>
	    </div>	
    	   )	
    	 }
    	 return null
    }) }
    </>
  );
}

export default SearchLicenseList