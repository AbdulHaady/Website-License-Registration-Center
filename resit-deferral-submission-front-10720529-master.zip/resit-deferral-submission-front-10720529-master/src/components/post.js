//this is used for the license
import React from 'react';
import { withRouter } from 'react-router';
import { Row, Col, Typography, Button} from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';//need this item 1



const { Title, Paragraph } = Typography;





class Post extends React.Component {
  
  static contextType = UserContext;//test item 2
  
  
  constructor(props){
    super(props);
    this.state = {
      post: undefined

    }
  }


  componentDidMount() { 
    
  const user = this.context.user;
  console.log("current user in UserContext is", user);
    
    console.log(user);
    
       let headers = new Headers();
      headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));   
    
    const id = this.props.match.params.id; // available using withRouter()    
    fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/licenses/${id}`, {headers: headers})
    .then(status)
    .then(json)
    .then(post => {
      this.setState({ post: post })
    })
    .catch(err => console.log("Error fetching license", err));
  }
  
  
  

  
  render(){
    if(!this.state.post){
      return<h3>Loading license...</h3>
      
    }
    
   const post = this.state.post;
    
          /// here//// logic
 
    return (
      <div>
         <Row type="flex" justify="space-around" align="middle">
          <Col span={6} align="center">
          <Title>{"   "}</Title>
          </Col>
         </Row>
        <Row type="flex" justify="space-around" align="middle">
          <Col span={6} align="center">
          </Col>
          <Col span={20}>
            <Title>{post.licenseName}</Title>
            <Paragraph>License ID : {post.licenseID}</Paragraph>
            <Paragraph>Requester : {post.requester}</Paragraph>
            <Paragraph>Date Request : {post.dateRequest}</Paragraph>
            <Paragraph>Status : {post.status}</Paragraph>
            <Paragraph>Description : {post.description}</Paragraph>
            <Paragraph>Company Name : {post.companyName}</Paragraph>
            <Paragraph>Company Adress : {post.companyAdress}</Paragraph>
  
          </Col>
          <Col span={6} align="center">
          </Col>
        </Row>



         <Row type="flex" justify="space-around" align="middle">
          <Col span= {6} >
          <Button type="primary"><Link to ={`/licenseUpdate/${post.licenseID}`}>Edit</Link></Button>
          </Col>
          <Col span={6} >
          <Button type="primary"><Link to ={`/licenseDelete/${post.licenseID}`}>Delete</Link></Button>
          </Col>
         </Row>



         <Row type="flex" justify="space-around" align="middle">
          <Col span={6} align="center">
          <Title>{"   "}</Title>
          </Col>
         </Row>
      </div>
    );
  }

}

export default withRouter(Post);