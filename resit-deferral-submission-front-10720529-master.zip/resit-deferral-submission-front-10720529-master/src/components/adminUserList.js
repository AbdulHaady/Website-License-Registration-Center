//same as postcard

import React from 'react';
import { Card } from 'antd';
import NavImage from './navImageT';


class AddUserList extends React.Component {
  


  render() {
    const postID = this.props.userID;
    return (
      <Card
        style={{ width: 600 }}

         cover={<NavImage alt={`Post ${postID}`} src="https://img.flaticon.com/icons/png/512/47/47774.png?size=1200x630f&pad=10,10,10,10&ext=png&bg=FFFFFFFF" to={`/postUser/${postID}`} />}
        hoverable={true}>
            {'User ID: '+this.props.userID} 
        <p>User Name : {this.props.userName}</p>

      </Card>
    );
  }
}

export default AddUserList; 