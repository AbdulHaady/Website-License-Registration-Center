import React from 'react';
import { PageHeader } from 'antd';
import UserAccount from './userAccount';



function Home(props) {
  return (
  <>
    <div className= "site-layout-content">
      <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="License Registration Center"
          subTitle= "Let Register a License."/>
       </div>
         <UserAccount />
      </div>
    </>
  );
}

export default Home;