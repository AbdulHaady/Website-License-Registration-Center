// this same as home
import React from 'react';
import { PageHeader } from 'antd';
import UserSearchLicense from './userSearchLicense';

import UserContext from '../contexts/user';


import { useContext } from 'react';


function LicenseHome (props){
  
  const context = useContext(UserContext);
  console.log(context);
  

    return(

          <div className= "site-layout-content">
          <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="License List"
          subTitle= "All the License is here!"/>
       </div>
       <UserSearchLicense />
      </div>


    );

};

export default LicenseHome;