import React, { useState, useEffect } from 'react';
import SearchLicenseBar from './searchLicenseBar';
import BlogGrid from './blogGridT';


import { PageHeader } from 'antd';

const SearchLicense = (props) => {
  
  
  const [input,setInput] = useState('');
  const [searchLicenseListDefault, setSearchLicenseListDefault] = useState();
  const [searchLicenseList, setSearchLicenseList] = useState();
  
  const fetchData = async () => {
    return await fetch('https://riviera-digital-3000.codio-box.uk/api/v1/licenses')
    .then(response => response.json())
    .then(data =>{setSearchLicenseList(data)
                 setSearchLicenseListDefault(data)});
  }
  
  const updateInput = async (input) =>{
      console.log("here",input);
      const filtered = searchLicenseListDefault.filter (license =>{
                                                 
       return license.licenseName.toLowerCase().includes(input.toLowerCase())})
      console.log("here", filtered);
      setInput(input);
      setSearchLicenseList(filtered);
}
  
  useEffect( ()=> {fetchData()}, []);
  
  return (
  <>

          <PageHeader className="site-page-header"
           title="License Registeration Center"
           subTitle ="Lets Get A license"/>
    
    
        <SearchLicenseBar
        input = {input}
        setKeyword = {updateInput}
    />
          
     <BlogGrid searchLicenseList = {searchLicenseList?searchLicenseList:[]} />
  </>
  );
}

export default SearchLicense;