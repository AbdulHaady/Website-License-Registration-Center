import React from 'react';
import { Form, Input, Button,PageHeader } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Redirect } from 'react-router-dom';

import UserContext from '../contexts/user';

// add some layout to keep the form organised on different screen sizes
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

// define validation rules for the form fields
const passwordRules = [
    { required: true, message: 'Please input your password!' }
];

const usernameRules = [
    { required: true, message: 'Please input your username!', whitespace: true }
]


/**
 * Login form component for app signup.
 */
class LoginForm extends React.Component {

    constructor(props) {
        super(props);
        this.login = this.login.bind(this);
    }

    state = {redirect: null}

    static contextType = UserContext;

    login(values) {
        const {userName, password} = values;
        console.log(`logging in user: ${userName}`)
        fetch('https://riviera-digital-3000.codio-box.uk/api/v1/users/login', {
            method: "POST",
            headers: {
                "Authorization": "Basic " + btoa(userName + ":" + password)
            }        
        })
        .then(status)
        .then(json)
        .then(user => {
            console.log('Logged in successfully');
            console.log(user);
            user.password = password;  // store in context for future API calls
            this.context.login(user);
            //this.setState({ redirect:'/' });
        })
        .catch(error => {
            // TODO: show nicely formatted error message
            console.log('Login failed');
        });  
    }
    
  render() {
    if (this.state.redirect) {
        return <Redirect to={this.state.redirect} />
    }    
    return (
     <div className= "site-layout-content">
      <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="Login "
          subTitle= "Please login to request license."/>
       </div>

      
        <Form {...formItemLayout} name="login" onFinish={this.login} scrollToFirstError >
            <Form.Item name="userName" label="Username" rules={usernameRules} >
                <Input />
            </Form.Item>
            <Form.Item name="password" label="Password" rules={passwordRules} hasFeedback >
                <Input.Password />
            </Form.Item>
            <Form.Item {...tailFormItemLayout}>
                <Button type="primary" htmlType="submit">Login</Button>
            </Form.Item>
        </Form>
       </div>

    );
  };
};

export default LoginForm;


