import React from 'react';
import { Form,Input,Button,PageHeader } from 'antd';
import { status, json } from '../utilities/requestHandlers';

/**
 * Registation form component for app signup.
 */

const formItemLayout ={
  labelCol: {xs: {span:24}, sm:{span:6}},
  wrapperCol: {xs:{span:24}, sm:{span:12}}
};


const btnFormItemLayout ={
    wrapperCol: { xs: {span:24, offset:6}, sm:{ span:16,offest:16}}
};

// Rules ==========================

const emailRules = [
  {type:'email', message:'example: new@new.com'},
  {required: true, message:'Please enter your E-mail'}
];

const passwordRules =[
  {required:true, message:'Please enter your password!'}
];

const usernameRules = [
  {required: true, message: 'Please enter your username!', whitespace:true}
];

const firstNameRules = [
  {required: true, message: 'Please enter your first name!', whitespace:true}
];

const lastNameRules = [
  {required: true, message: 'Please enter your last name!', whitespace:true}
];

const phoneNoRules = [
  {required: true, message: 'Please enter your phone number!', whitespace:true}
];

const confirmRules = [
  {required: true, message:'Please confirm your password!'},
  // rules can include function handlers in which you can apply logic
  ({getFieldValue})=>({
    validator(rule, value){
      if(!value||getFieldValue('password')===value){
        return Promise.resolve();
      }
      return Promise.reject('The password that you entered do not match!');
    }
  })
];

// ===================================

class RegistrationForm extends React.Component{
  
  constructor(props){
    super(props);
    this.onFinish = this.onFinish.bind(this);
  }
  
  onFinish = (values) => {
    console.log('Recieved values of form: ', values);
    const {confirm, ...data}= values; //ignore the 'confirm' value
    
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
        
    console.log("User Create Test", headers); //checking error
    
    fetch('https://riviera-digital-3000.codio-box.uk/api/v1/users',{
      method:"POST",
      body:JSON.stringify(data),
      headers:headers
    })
    .then(status)
    .then(json)
    .then(data=>{
         //For you TODO: display success message and/or redirect
         console.log(data);
         alert("User added")
    })
    .catch(error =>{
      //For you TODO: show nicely formatted error message and clear form
        console.error(error);
      alert(`Error:${error}`);
    });
  };
  
  
  render(){
    return(
          <div className= "site-layout-content">
      <div style={{ padding: '2% 20%'}}>
        <PageHeader className= "site-page-header"
          title="Register Your Account Here"
          subTitle= "Create your user account"/>
       </div>

    <Form {...formItemLayout} name="register" onFinish={this.onFinish} scrollToFirstError>
      
      <Form.Item  name="userName" label="User Name" rules={usernameRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="firstName" label="First Name" rules={firstNameRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="lastName" label="Last Name" rules={lastNameRules}>
        <Input />
      </Form.Item >
      
      <Form.Item name="email" label="E-mail" rules={emailRules}>
        <Input />
      </Form.Item >

      <Form.Item  name="phoneNo" label="Phone Number" rules={phoneNoRules}>
        <Input />
      </Form.Item >
      
      <Form.Item  name="password" label="Password" rules={passwordRules} hasFeedback>
        <Input.Password/>
      </Form.Item>
      
      <Form.Item  name="confirm" label="Confirm Password" dependencies={['password']} hasFeedback rules={confirmRules}>
        <Input.Password />
      </Form.Item>
      
      <Form.Item {...btnFormItemLayout} >
        <Button  type="primary" htmlType="submit">
          Register
        </Button>
      </Form.Item>
     </Form>

      </div>
      
    );
  };
};

export default RegistrationForm;