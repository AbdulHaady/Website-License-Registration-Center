import React from 'react';
import { Form, Input, Button, PageHeader, Row, Col } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';//test for the user context item 1



// layout =========================================================================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};


// ==================================================================================================

class LicenseUpdateStaff extends React.Component {
  

    
    constructor(props) {
        super(props);
        this.licenseUpdate = this.licenseUpdate.bind(this);
    }
  

     static contextType = UserContext;//test for the user Context item 2
  
    // The experiment begins......

  
  //
    
    licenseUpdate = (values) => {
        console.log('Received values of form: ', values);
        const {licenseID, ...data} = values;  // ignore the 'confirm' value in data sent

        const user = this.context.user;
       
        let headers = new Headers();
        headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));      
        headers.append('Content-Type', 'application/json');
        


      
        console.log(values.licenseID);
        
      
        fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/licenses/${values.licenseID}`, {
            method: "PUT",
            body: JSON.stringify(data),
            headers:headers
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("license updated")

            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
  
  

    
    render() {
      

        
        return (
          
           <div className= "site-layout-content">
          <div style={{ padding: '2% 20%'}}>
          <PageHeader className= "site-page-header"
          title="Update Your License"
          subTitle= "Enter your new license infromation"/>
       </div>



            <Form {...formItemLayout} name="licenseUpdate" onFinish={this.licenseUpdate} scrollToFirstError >
              
                      <Form.Item  name="licenseID" label="license ID" >
                        <Input />
                      </Form.Item >
                      <Form.Item  name="status" label="Status " >
                        <Input />
                      </Form.Item >
              
            




                <Form.Item {...tailFormItemLayout}>
                  <Row>
                  <Col span={8}>
                    <Button type="primary" htmlType="submit">Update License</Button>
                  </Col>
                  <Col span={8}>
                    <Button type = "primary"><Link to = "/">Back</Link></Button>
                   </Col>
                   </Row>
                </Form.Item>
            </Form>

      </div>
        );
    };
};

export default LicenseUpdateStaff;