import React from 'react';
import { Menu } from 'antd';
import { Link } from "react-router-dom";
import UserContext from '../contexts/user';
import { useContext } from 'react';
               
                   
const {SubMenu} = Menu;

function Nav(props) {
  
    const context = useContext(UserContext);
    const loggedIn = context.user.loggedIn;
    const role = context.user.role;

    console.log(context);
  
    let LoginNav;
  
    if (!loggedIn){
      
      LoginNav = (
        
        <>
        
        <Menu.Item key ="2"><Link to ="/login">Login</Link></Menu.Item>
        <Menu.Item key ="3"><Link to ="/register">Register</Link></Menu.Item>

        </>
      
      )
    }
  
    else if (role === 'user'){
          
          LoginNav = (
          
            <>
                <SubMenu key = "2"  title = "User ">
                    <Menu.Item key="setting:2"><Link to="/userDelete">Delete Account</Link></Menu.Item>
                    <Menu.Item key="setting:3"><Link to="/userUpdate">Update Account</Link></Menu.Item>

                </SubMenu>
                <SubMenu key = "3"  title = "license">
                     <Menu.Item key="setting:4"><Link to="/licenseCreate">Request License</Link></Menu.Item>
                     <Menu.Item key="setting:5"><Link to="/userLicense">User License</Link></Menu.Item>
                </SubMenu>
               <Menu.Item key="4" onClick = {context.logout}><Link to ="/">Log Out</Link></Menu.Item>
            </>

          )
    }

    else if (role === 'staff'){
          
          LoginNav = (
          
            <>

               <Menu.Item key="2"><Link to ="/staffLicenseSearchPage">License</Link></Menu.Item>
               <Menu.Item key="3" onClick = {context.logout}><Link to ="/">Log Out</Link></Menu.Item>
            </>
          )
    }

    else if (role === 'admin'){
          
          LoginNav = (
          
            <>
            

                <SubMenu key = "2" title = "User">
 
                    <Menu.Item key="setting:2"><Link to="/adminDisplayUser">All User</Link></Menu.Item>
                    <Menu.Item key="setting:3"><Link to="/adminUpdateUser">Update User</Link></Menu.Item>
                    <Menu.Item key="setting:4"><Link to="/adminDeleteUser">Delete User</Link></Menu.Item>
            
                </SubMenu>
                <SubMenu key = "3"  title = "license">
            
                     <Menu.Item key="setting:5"><Link to="/staffLicenseSearchPage">All License</Link></Menu.Item>
                     
            
            
                </SubMenu>
               <Menu.Item key="4" onClick = {context.logout}><Link to ="/">Log Out</Link></Menu.Item>
            
                 
            </>
          )
    }
  
  return (
    <>
      <div className="logo" />
      <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['1']}>

        <Menu.Item key="1"><Link to="/">Home</Link></Menu.Item>

         {LoginNav}
      </Menu>
    </>
  );
}

export default Nav;