import React from 'react';
import {Row, Col, Form, Button } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';

// layout ===========================================================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

// class ==============================================================================

class DeleteForm extends React.Component {
    
    constructor(props) {
        super(props);
        this.delete = this.delete.bind(this);
    }
    
    static contextType = UserContext;
    
    delete () {
        
        const user = this.context.user;
        
         let headers = new Headers();
         headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));
        
        fetch(user.links.self, {
            method: "DELETE",
            headers:headers
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("User deleted")
            
            this.context.logout(user);
            this.setState({redirect:'/'});
            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
    
    render() {
        
        return (

            <Form {...formItemLayout} name="delete" onFinish={this.delete} scrollToFirstError >
            
                <h1> Are You Sure You Want To Delete Your Account? </h1>

                <Form.Item {...tailFormItemLayout}>

                     <Row type="flex" justify="space-around" align="middle">
                      <Col span= {6} >
                    <Button type="primary" htmlType="submit">Delete</Button>
                      </Col>
                      <Col span={6} >
                    <Button type = "primary"><Link to = "/">No</Link></Button>
                      </Col>
                     </Row>

                  </Form.Item>


            </Form>
        );
    };
};

export default DeleteForm;