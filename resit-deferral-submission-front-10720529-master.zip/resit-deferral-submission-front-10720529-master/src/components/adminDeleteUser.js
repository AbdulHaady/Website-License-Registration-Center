import React from 'react';
import { Form, Button, Input, Row, Col } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';

// layout ========================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

//=============================================

class UserDelete extends React.Component {
    
    constructor(props) {
        super(props);
        this.userDelete = this.userDelete.bind(this);
    }
    
    static contextType = UserContext;
    
    userDelete (values) {
      
        console.log('Received values of form: ', values);
        const {userID, ...data} = values;  // ignore the 'confirm' value in data sent  
      
      
        const user = this.context.user;
        
         let headers = new Headers();
         headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));
        
         console.log(values.userID);     
      
      
      
      
        fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/users/${values.userID}`, {
            method: "DELETE",
            headers:headers
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("user Deleted")
            
            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
    
    render() {
        
        return (

            <Form {...formItemLayout} name="userDelete" onFinish={this.userDelete} scrollToFirstError >
            
                <h1> Are You Sure You Want To Delete This User? </h1>

                <Form.Item name="userID" label="User ID" >
                    <Input />
                </Form.Item>

                <Form.Item {...tailFormItemLayout}>
                  <Row>
                  <Col span={8}>                  
                    <Button type="primary" htmlType="submit">Delete</Button>
                  </Col>
                  <Col span={8}>
                    <Button type = "primary"><Link to = "/">No</Link></Button>
                   </Col>
                   </Row>                      

                </Form.Item>
            </Form>
        );
    };
};

export default UserDelete;