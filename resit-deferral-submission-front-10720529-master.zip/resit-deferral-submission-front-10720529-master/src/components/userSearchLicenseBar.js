import React from 'react';
import UserContext from '../contexts/user';
import {useContext} from 'react';



const SearchLicenseBar = ({keyword, setKeyword}) => {
  
  const context = useContext(UserContext);
  const user = context.user;
  console.log("current user in UserContext is", user.userName);
  
  const BarStyling = {width:"50rem",background:"#F2F1F9", border:"none", padding:"0.5rem"};
  return (
    <input 
     style = {BarStyling}
     key = "random1"
     value = {keyword}
     placeholder = {user.userName}
     onChange={(e) => setKeyword(e.target.value)}
    />
  );
}

export default SearchLicenseBar;