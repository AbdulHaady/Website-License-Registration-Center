import React from 'react';
import { Form, Button, Input, Row, Col } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";



// layout ========================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

//=============================================

class LicenseDelete extends React.Component {
    
    constructor(props) {
        super(props);
        this.licenseDelete = this.licenseDelete.bind(this);
    }
    

    
    licenseDelete (values) {
        console.log('Received values of form: ', values);
        const {licenseID, ...data} = values;  // ignore the 'confirm' value in data sent  
      
        
         console.log(values.licenseID);     
      
      
      
      
        fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/licenses/${values.licenseID}`, {
            method: "DELETE"
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("license Deleted")
            
            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
    
    render() {
        
        return (

            <Form {...formItemLayout} name="licenseDelete" onFinish={this.licenseDelete} scrollToFirstError >
            
                <h1> Are You Sure You Want To Delete This License? </h1>

                <Form.Item name="licenseID" label="License ID" >
                    <Input />
                </Form.Item>

                <Form.Item {...tailFormItemLayout}>
                  <Row>
                  <Col span={8}>                  
                    <Button type="primary" htmlType="submit">Delete</Button>
                  </Col>
                  <Col span={8}>
                    <Button type = "primary"><Link to = "/licenseDisplayList">No</Link></Button>
                   </Col>
                   </Row>                      

                </Form.Item>
            </Form>
        );
    };
};

export default LicenseDelete;