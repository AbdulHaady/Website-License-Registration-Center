import React from 'react';
import { Form, Input, Button, PageHeader, Row, Col } from 'antd';
import { status, json } from '../utilities/requestHandlers';
import { Link } from "react-router-dom";

import UserContext from '../contexts/user';//test for the user context item 1


// layout =========================================================================================
const formItemLayout = {
  labelCol: { xs: { span: 24 }, sm: { span: 6 } },
  wrapperCol: { xs: { span: 24 }, sm: { span: 12 } }
};
const tailFormItemLayout = {
  wrapperCol: { xs: { span: 24, offset: 0 }, sm: { span: 16, offset: 6 } },
};

// Rules ============================================================================================

const userIDRules = [
    { required: true, message: 'Please input the user ID!', whitespace: true }
]

const userNameRules = [
    { required: true, message: 'Please input  username!', whitespace: true }
]

const firstNameRules = [
    { required: true, message: 'Please input  first name!', whitespace: true }
]

const lastNameRules = [
    { required: true, message: 'Please input  last name!', whitespace: true }
]

const emailRules = [
    {type: 'email', message: 'The input is not valid E-mail!'},
    {required: true, message: 'Please input E-mail!' }
];

const passwordRules = [
    { required: true, message: 'Please input password!' }
];

const confirmRules = [
    { required: true, message: 'Please confirm your password!' },
    // rules can include function handlers in which you can apply additional logic
    ({ getFieldValue }) => ({
        validator(rule, value) {
            if (!value || getFieldValue('password') === value) {
                return Promise.resolve();
            }
            return Promise.reject('The two passwords that entered do not match!');
        }
    })
];



const phoneRules = [
    { required: true, message: 'Please input your phone number!', whitespace: true }
];



// ==================================================================================================

class UserUpdate extends React.Component {
  
     static contextType = UserContext;//test for the user Context item 2
    
    constructor(props) {
        super(props);
        this.userUpdate = this.userUpdate.bind(this);
    }
    

    userUpdate = (values) => {
        console.log('Received values of form: ', values);
        const {userID, ...data} = values;  // ignore the 'confirm' value in data sent

        const user = this.context.user;
       
        let headers = new Headers();
        headers.append('Authorization', 'Basic ' + btoa(user.userName + ":" + user.password));
        headers.append('Content-Type', 'application/json');
        


      
        console.log(values.userID);
        
      
        fetch(`https://riviera-digital-3000.codio-box.uk/api/v1/users/${values.userID}`, {
            method: "PUT",
            body: JSON.stringify(data),
            headers:headers
        })
            .then(status)
            .then(json)
            .then(data => {
            console.log(data);
            alert("User updated")

            })
        
            .catch(error => {
            // TODO: show nicely formatted error message and clear form
            alert(`Error: ${JSON.stringify(error)}`);
        });  
    };
    
    render() {
        
        return (
          
           <div className= "site-layout-content">
          <div style={{ padding: '2% 20%'}}>
          <PageHeader className= "site-page-header"
          title="Update Your User Info"
          subTitle= "Enter your new user infromation"/>
       </div>

            <Form {...formItemLayout} name="userUpdate" onFinish={this.userUpdate} scrollToFirstError >
              
                       <Form.Item  name="userID" label="User ID" rules={userIDRules}>
                        <Input />
                      </Form.Item >
              
                      <Form.Item  name="userName" label="User Name" rules={userNameRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="firstName" label="First Name" rules={firstNameRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="lastName" label="Last Name" rules={lastNameRules}>
                        <Input />
                      </Form.Item >
              
            
                      <Form.Item  name="password" label="Password" rules={passwordRules}>
                        <Input.Password />
                      </Form.Item >

                      <Form.Item name="saltedPassword" label="Confirm Password" rules={confirmRules}>
                          <Input.Password />
                      </Form.Item>


                      <Form.Item  name="phoneNo" label="Phone Number" rules={phoneRules}>
                        <Input />
                      </Form.Item >

                      <Form.Item  name="email" label="E-mail" rules={emailRules}>
                        <Input />
                      </Form.Item >


                <Form.Item {...tailFormItemLayout}>
                  <Row>
                  <Col span={8}>
                    <Button type="primary" htmlType="submit">Update User</Button>
                  </Col>
                  <Col span={8}>
                    <Button type = "primary"><Link to = "/">Back</Link></Button>
                   </Col>
                   </Row>
                </Form.Item>
            </Form>

      </div>
        );
    };
};

export default UserUpdate;